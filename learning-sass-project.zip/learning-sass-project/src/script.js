//begin dark mode button, switched from Jquery to Umbrella.JS
u(".dark-mode-button").on('click', function(e) {
  let $this = u(this);
  u(this).toggleClass("on");
  u('body').toggleClass("darkmode");
  u('.box').toggleClass("box-dark");
  u('.header').toggleClass("header-dark");
  u('.footer').toggleClass("footer-dark");
  u('.title-text').toggleClass("light-text");
  u('.icon-container').toggleClass("light-icons")
  switch ($this.attr("aria-checked"))
  {
    case "false":
      $this.attr("aria-checked", "true");
      break;
    case "true":
      $this.attr("aria-checked", "false");
      break;
    default:
      $this.attr("aria-checked", "true");
  }

})
//header scroll
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 70 || document.documentElement.scrollTop > 70) {
    document.getElementById("header").style.height = "15vh";
  } else {
    document.getElementById("header").style.height = "20vh";
  }
}
//keep fucking with this https://www.w3schools.com/howto/howto_js_shrink_header_scroll.asp